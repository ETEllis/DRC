# Validation receipt — v1.0

Completed 25 September 2026.

- Publication PDF: 22 pages; page images inspected for layout and legibility. Figures preserve directional arrowheads and explicit dashed uncertainty paths. The evidence ledger avoids splitting a claim block across pages.
- Browser execution: Chromium with Playwright; no JavaScript page errors.
- Responsive checks: 390, 768 and 1440 CSS-pixel widths, with no page-level horizontal overflow.
- Functional checks passed: keyboard-selectable arrows; expandable layers; evidence filtering; RCB equation and reset; handoff-stage slider; alternative causal DAGs; bibliography search and empty state; mobile claim selection; reduced-motion support.
- Structure checks passed: unique HTML IDs, diagram text fits its boxes, local file links and fragment targets resolve, all claim/citation references resolve.
- Offline checks: opened directly using file URLs; no runtime fetch dependencies. JavaScript-disabled view retains full manuscript, static diagrams, evidence ledger, bibliography and downloads.
- Print fallback: generated in Chromium with JavaScript disabled. Full reference/claim material is retained.
- Preservation checks: SHA-256 equality for both supplied PDFs and the supplied extension, recorded in SOURCE_MANIFEST.json.
- Research limitations and remaining author/journal checks: see STRENGTHENING_PASS.md.

Not claimed: exhaustive accessibility certification; testing in every browser/device; systematic-review completeness; biological model validation; external GitHub publication. No target repository was specified or created.
