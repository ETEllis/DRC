# Canonical directive and implementation boundary

The current user's explicit DIRECTIVE CODEX (25 September 2026) supersedes incomplete prior-chat retrieval. It authorizes integration → tightening → publication formalization → interactive web instantiation.

Canonical corpus:
1. RCCX–Hunter–Dąbrowski Cascade v3.2.
2. The Polymathic Singularity v0.1.
3. Perinatal Regulatory Initialization / α₂δ–CaV2 Extension draft.
4. Relevant associated notes, literature anchors, diagrams, causal models, equations and evidence-status labels available through those sources.

Required deliverables: formal publication-format manuscript; polished responsive static GitHub Pages research experience; data-driven repository; strengthening pass including contrary evidence, species/stage boundaries, verified numbers, simplified terminology, explicit DAGs and minimum discriminating studies.

Preserve: established mechanism ≠ supported synthesis ≠ proposed mechanism ≠ horizon hypothesis. Every major arrow gets sources and a grade; background citations must not turn an unsupported bridge into a fact. The central causal sequence retains recursion, environmental coupling and heterogeneity.

The available workspace is a ChatGPT Work execution workspace, not a connected checkout on the author's Mac. No claim is made that a local Mac Codex session was opened or that a GitHub repository was created. The deliverable is a complete local, portable implementation ready to transfer or deploy.
