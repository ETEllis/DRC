from pathlib import Path
import zipfile
ROOT=Path(__file__).resolve().parents[1]
path=ROOT/'research-source.zip'
with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(ROOT.rglob('*')):
  if f.is_file() and f!=path and '.git' not in f.parts and '__pycache__' not in f.parts:z.write(f,f.relative_to(ROOT))
print(path)
