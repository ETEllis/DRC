# The Developmental Regulatory Cascade

E. T. Ellis · Integrated research program v1.0 · 25 September 2026

A responsive static research atlas and a publication-format hypothesis manuscript. The landing page is the interactive theory: selectable connections and layers, evidence filters, molecular and microbial pathways, Regulatory Closure Bias controls, competing DAGs, predictions, experiments, bibliography and source papers.

## Open it

Open `index.html` directly in a modern browser, or serve this directory with `python3 -m http.server 8000`. Runtime dependencies: none. All data, styles and code are local. External connections occur only when a reader follows a scholarly or GitHub link. No analytics, forms, personal-data collection, cookies or external fonts are included.

## GitHub Pages

This package is prepared for a new repository or a dedicated directory, not an overwrite of an existing project. No target repository was provided and this package has not been published.

1. Put the repository contents at the root of your chosen GitHub repository.
2. Under Settings → Pages, use Deploy from a branch, select your branch and `/ (root)`, and save.
3. Set `repository_url` in `data/config.json` to that repository's real URL and rebuild. Until then, the site correctly links to the author's verified GitHub profile and a downloadable source archive; it does not invent a repository URL.

All paths are relative and work under a GitHub Pages repository subpath. `.nojekyll` is included. No domain, credentials or deployment account is assumed.

## Source of truth

- `papers/integrated-paper.md`: authored manuscript and generated scholarly appendices.
- `data/evidence.json`: 20 claims with class, design code, preparation, uncertainty, falsifier and citation IDs.
- `data/mechanisms.json`: layers and major diagram connections.
- `data/citations.json`: 24 scholarly/project references.
- `data/predictions.json`: eight predictions tied to studies A–C.
- `data/config.json`: version, author, date and eventual repository URL.
- `src/style.css`, `src/app.js`: presentation and behavior.
- `scripts/build.py`: emits static HTML, bundled data, diagram assets and the paper PDF.
- `docs/STRENGTHENING_PASS.md`: corrections, counterevidence and remaining submission gates.
- `docs/VALIDATION.md`: actual validation receipt.

`src/data.js` and `index.html` are generated. Edit the JSON and manuscript, then run `python3 scripts/build.py`. The PDF builder needs Python 3, ReportLab, PyMuPDF, Pillow and DejaVu fonts installed at `/usr/share/fonts/truetype/dejavu/`; adapt that font path for another OS. Reading and deploying the built site needs none of these. `scripts/seed_data.py` records the initial v1.0 dataset; rerunning it intentionally resets JSON to that original dataset, so do not run it after literature updates.

Regenerate the downloadable source zip with `python3 scripts/package.py`. The source archive excludes itself to avoid recursive archives. The distribution zip includes the source archive.

## Evidence semantics

Established mechanism, supported synthesis, proposed mechanism and horizon hypothesis are separate categories. E0–E5 describe evidence designs, not probabilities or a linear certainty scale. Species and stage are attached to claims. The central perinatal-to-α₂δ bridge is E0. Disabling proposed/horizon filters should disconnect the complete cascade.

The handoff chart is qualitative, with no measured contribution fractions. RCB sliders use arbitrary positive inputs to illustrate a proposed index. Neither control is a diagnostic, clinical or predictive model.

## Provenance

The two original PDFs and extension are preserved as supplied. Their conceptual content is integrated and tightened in the new manuscript; they have not been silently rewritten or relabeled as updated originals. The author's directive scope is recorded in `docs/AUTHORITY.md` as a scoped implementation record. The full prior chat archive was not available; the three named documents and the explicit directive supplied in this conversation are the source boundary.

This is a substantive publication-format draft, not a peer-reviewed result or a certified submission-ready systematic review. Full-text/abstract access varied across studies; no raw study datasets were audited. Funding, competing-interest declarations, author review and journal-specific requirements remain submission steps.
